package ds.inaturalistservlet;

//name: Anran Lin
//andrewID: anranlin

import java.util.List;

public class ResponseSpecies {
    private int total_results;
    private int page;
    private int perPage;
    private List<Result> results;

    // getters and setters


    public int getTotal_results() {
        return total_results;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPerPage() {
        return perPage;
    }

    public void setPerPage(int perPage) {
        this.perPage = perPage;
    }

    public List<Result> getResults() {
        return results;
    }

    public void setResults(List<Result> results) {
        this.results = results;
    }

    public static class Result {
        private int count;
        private Taxon taxon;

        // getters and setters


        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public Taxon getTaxon() {
            return taxon;
        }

        public void setTaxon(Taxon taxon) {
            this.taxon = taxon;
        }

        public static class Taxon {
            private int id;
            private int iconicTaxonId;
            private String iconicTaxonName;
            private boolean isActive;
            private String name;
            private String preferredCommonName;
            private String rank;
            private int rankLevel;
            private List<Integer> ancestorIds;
            private List<Color> colors;
            private ConservationStatus conservationStatus;
            private List<ConservationStatus> conservationStatuses;
            private Photo default_photo;
            private EstablishmentMeans establishmentMeans;
            private int observations_count;
            private String preferredEstablishmentMeans;

            public String getWikipedia_url() {
                return wikipedia_url;
            }

            private String wikipedia_url;


            // getters and setters


            public int getId() {
                return id;
            }

            public int getIconicTaxonId() {
                return iconicTaxonId;
            }

            public String getIconicTaxonName() {
                return iconicTaxonName;
            }

            public boolean isActive() {
                return isActive;
            }

            public String getName() {
                return name;
            }

            public String getPreferredCommonName() {
                return preferredCommonName;
            }

            public String getRank() {
                return rank;
            }

            public int getRankLevel() {
                return rankLevel;
            }

            public List<Integer> getAncestorIds() {
                return ancestorIds;
            }

            public List<Color> getColors() {
                return colors;
            }

            public ConservationStatus getConservationStatus() {
                return conservationStatus;
            }

            public List<ConservationStatus> getConservationStatuses() {
                return conservationStatuses;
            }

            public Photo getDefaultPhoto() {
                return default_photo;
            }

            public EstablishmentMeans getEstablishmentMeans() {
                return establishmentMeans;
            }

            public int getObservationsCount() {
                return observations_count;
            }

            public String getPreferredEstablishmentMeans() {
                return preferredEstablishmentMeans;
            }

            public static class Color {
                private int id;
                private String value;

                // getters and setters

                public int getId() {
                    return id;
                }

                public String getValue() {
                    return value;
                }
            }

            public static class ConservationStatus {
                private int placeId;
                private Place place;
                private String status;

                public int getPlaceId() {
                    return placeId;
                }

                public Place getPlace() {
                    return place;
                }

                public String getStatus() {
                    return status;
                }

                // getters and setters
            }

            public static class Photo {
                private int id;
                private String attribution;
                private String licenseCode;
                private String url;
                private String medium_url;
                private String squareUrl;

                // getters and setters

                public int getId() {
                    return id;
                }

                public String getAttribution() {
                    return attribution;
                }

                public String getLicenseCode() {
                    return licenseCode;
                }

                public String getUrl() {
                    return url;
                }

                public String getMediumUrl() {
                    return medium_url;
                }

                public String getSquareUrl() {
                    return squareUrl;
                }
            }

            public static class EstablishmentMeans {
                private String establishmentMeans;
                private Place place;

                // getters and setters

                public String getEstablishmentMeans() {
                    return establishmentMeans;
                }

                public Place getPlace() {
                    return place;
                }
            }
        }
    }

    public static class Place {
        private int id;
        private String name;
        private String displayName;

        // getters and setters

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getDisplayName() {
            return displayName;
        }
    }
}
