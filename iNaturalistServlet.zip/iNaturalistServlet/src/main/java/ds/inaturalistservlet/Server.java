package ds.inaturalistservlet;

//name: Anran Lin
//andrewID: anranlin

import java.io.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

import java.net.*;

import com.google.gson.Gson;

import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "iNaturalistServlet", value = "/inaturalist")
public class Server extends HttpServlet {

    String searchTerm = null;
    String selectedMonth;
    String selectedYear;
    String selectedArea;
    ResponseSpecies responseSpecies;
    String IP;
    private String requestTimestamp;
    private String api1Url;
    private String api1Response = null;
    private String api2Url;
    private String api2Response = null;
    private String responseToPhone;
    private String responseTimestamp;


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        long timestamp = System.currentTimeMillis();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd:HH-mm-ss");
        requestTimestamp = sdf.format(new Date(timestamp));

        // deal with json data
        StringBuilder sb = new StringBuilder();
        String s;
        while ((s = request.getReader().readLine()) != null) {
            sb.append(s);
        }
        Gson gson = new Gson();
        SearchRequest searchRequest = gson.fromJson(sb.toString(), SearchRequest.class);

        // initialize
        this.IP = searchRequest.getIP();
        this.searchTerm = searchRequest.getSearchTerm();
        this.selectedArea = searchRequest.getSelectedArea();
        this.selectedYear = searchRequest.getSelectedYear();
        this.selectedMonth = searchRequest.getSelectedMonth();

        // obtain the longitude and latitude
        IPAddress geoMessage = getGeoMessage(IP);

        String urlString = null;
        if(selectedMonth!=null){
            urlString = "https://api.inaturalist.org/v1/observations/species_counts?" +
                    "taxon_name=" + searchTerm +
                    "&month=" + selectedMonth +
                    "&lat="+ geoMessage.getLatitude()+
                    "&lng="+ geoMessage.getLongitude()+
                    "&radius=" + selectedArea;
        }
        else if(selectedYear!=null){
            urlString = "https://api.inaturalist.org/v1/observations/species_counts?" +
                    "taxon_name=" + searchTerm +
                    "&year=" + selectedYear +
                    "&lat="+ geoMessage.getLatitude()+
                    "&lng="+ geoMessage.getLongitude()+
                    "&radius=" + selectedArea;
        }
        System.out.println("here "+ urlString);
        api2Url = urlString;


        try {

            URL url = new URL(urlString);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            int status = con.getResponseCode();
            if (status == HttpURLConnection.HTTP_OK) {
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder content = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();
                responseSpecies =  gson.fromJson(content.toString(), ResponseSpecies.class);
                api2Response = Integer.toString(responseSpecies.getTotal_results());


            } else {
                System.out.println("GET request not worked");
            }

            con.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String jsonResponse = gson.toJson(responseSpecies);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print(jsonResponse);
        out.flush();

        // End of Response, then take log
        long endtimestamp = System.currentTimeMillis();
        // System.out.println(endtimestamp);
        SimpleDateFormat esdf = new SimpleDateFormat("yyyy-MM-dd:HH-mm-ss");
        responseTimestamp = esdf.format(new Date(endtimestamp));
        responseToPhone = Integer.toString(jsonResponse.length());
        // System.out.println(jsonResponse.length());

        LogEntry logEntry = new LogEntry(
                IP,
                searchTerm,
                selectedMonth,
                selectedYear,
                selectedArea,
                requestTimestamp,
                api1Url,
                api1Response,
                api2Url,
                api2Response,
                responseToPhone,
                responseTimestamp
        );

        System.out.println(api2Response);

        MongoDBUtil.insertLog(logEntry);

    }

    private IPAddress getGeoMessage(String IP) {

        String urlString = "https://ipapi.co/"+IP+"/json/";

        api1Url = urlString;

        //System.out.println("here ip search:"+urlString);

        try {
            URL url = new URL(urlString);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            //System.out.println("here checkpoint1");

            int status = con.getResponseCode();
            //System.out.println("here === "+status);
            if (status == HttpURLConnection.HTTP_OK) {
                //System.out.println("here checkpoint2");
                BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
                String inputLine;
                StringBuilder content = new StringBuilder();
                while ((inputLine = in.readLine()) != null) {
                    content.append(inputLine);
                }
                in.close();

                Gson gson = new Gson();
                //System.out.println("here complete geo message search");
                api1Response = content.toString();
                return gson.fromJson(content.toString(), IPAddress.class);
            } else {
                System.out.println("GET request not worked");
            }

            con.disconnect();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }


}