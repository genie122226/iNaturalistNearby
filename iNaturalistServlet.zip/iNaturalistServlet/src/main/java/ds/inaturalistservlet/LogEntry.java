package ds.inaturalistservlet;

import org.bson.Document;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

public class LogEntry {
    private String ip;
    private String searchTerm;
    private String selectedMonth;
    private String selectedYear;
    private String selectedArea;
    private String requestTimestamp;
    private String api1Url;
    private String api1Response;
    private String api2Url;
    private String api2Response;
    private String responseToPhone;
    private String responseTimestamp;


    public LogEntry(String ip, String searchTerm, String selectedMonth, String selectedYear, String selectedArea, String requestTimestamp, String api1Url, String api1Response, String api2Url, String api2Response, String responseToPhone, String responseTimestamp) {
        this.ip = ip;
        this.searchTerm = searchTerm;
        this.selectedMonth = selectedMonth;
        this.selectedYear = selectedYear;
        this.selectedArea = selectedArea;
        this.requestTimestamp = requestTimestamp;
        this.api1Url = api1Url;
        this.api1Response = api1Response;
        this.api2Url = api2Url;
        this.api2Response = api2Response;
        this.responseToPhone = responseToPhone;
        this.responseTimestamp = responseTimestamp;
    }


    public Document toDocument() {
        return new Document("ip", ip)
                .append("searchTerm", searchTerm)
                .append("selectedMonth", selectedMonth)
                .append("selectedYear", selectedYear)
                .append("selectedArea", selectedArea)
                .append("requestTimestamp", requestTimestamp)
                .append("api1Url", api1Url)
                .append("api1Response", api1Response)
                .append("api2Url", api2Url)
                .append("api2Response", api2Response)
                .append("responseToPhone", responseToPhone)
                .append("responseTimestamp", responseTimestamp);
    }
}