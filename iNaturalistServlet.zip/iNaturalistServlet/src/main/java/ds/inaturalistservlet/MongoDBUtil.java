package ds.inaturalistservlet;


import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class MongoDBUtil {

    private static MongoClient mongoClient = null;

    public static MongoDatabase getDatabase() {
        if (mongoClient == null) {
            String connectionString = "mongodb://xilouhexi:d4daBSH2R2ruyX21@ac-mvrozk9-shard-00-00.99f3ywm.mongodb.net:27017,ac-mvrozk9-shard-00-01.99f3ywm.mongodb.net:27017,ac-mvrozk9-shard-00-02.99f3ywm.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";

            ServerApi serverApi = ServerApi.builder()
                    .version(ServerApiVersion.V1)
                    .build();

            MongoClientSettings settings = MongoClientSettings.builder()
                    .applyConnectionString(new ConnectionString(connectionString))
                    .serverApi(serverApi)
                    .build();

            mongoClient = MongoClients.create(settings);
        }
        return mongoClient.getDatabase("iNaturalist");
    }

    public static void insertLog(LogEntry logEntry) {
        MongoDatabase database = getDatabase();
        Document logDocument = logEntry.toDocument();
        database.getCollection("logs").insertOne(logDocument);
    }

    public static List<Document> getLogs() {
        List<Document> logs = new ArrayList<>();
        MongoDatabase database = getDatabase();
        MongoCollection<Document> collection = database.getCollection("logs");

        try (MongoCursor<Document> cursor = collection.find().iterator()) {
            while (cursor.hasNext()) {
                logs.add(cursor.next());
            }
        }

        return logs;
    }

    public static void close() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}
