package ds.inaturalistservlet;

import java.io.*;
import java.text.ParseException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;
import jakarta.servlet.RequestDispatcher;
import java.util.HashMap;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date;

//name: Anran Lin
//andrewID: anranlin

@WebServlet(name = "LogDashboardServlet", value = "/dashboard")
public class LogDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<Document> logs = MongoDBUtil.getLogs();

        Map<String, Integer> ipCountMap = new HashMap<>();
        Map<String, Integer> searchTermMap = new HashMap<>();
        long averageTime = 0, sumTime = 0;

        for(Document log:logs){
            String ip = log.getString("ip");

            if (ipCountMap.containsKey(ip)) {
                ipCountMap.put(ip, ipCountMap.get(ip) + 1);
            } else {
                ipCountMap.put(ip, 1);
            }

            String searchTerm = log.getString("searchTerm");
            System.out.println(searchTerm);

            if (searchTermMap.containsKey(searchTerm)) {

                searchTermMap.put(searchTerm, searchTermMap.get(searchTerm) + 1);
            } else {
                searchTermMap.put(searchTerm, 1);
            }

            String StartTime = log.getString("requestTimestamp");
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd:HH-mm-ss");
            Date date = null;
            try {
                date = sdf.parse(StartTime);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            long startTime = date.getTime();

            String EndTime = log.getString("responseTimestamp");
            try {
                date = sdf.parse(EndTime);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
            long endTime = date.getTime();
            long operationTime = endTime-startTime;
            sumTime+=operationTime;
        }

        averageTime = sumTime / logs.size();

        // Find the most frequently occurring search IP and its corresponding count
        String mostCommonIp = null;
        int maxIPCount = 0;

        for (Map.Entry<String, Integer> entry : ipCountMap.entrySet()) {
            if (entry.getValue() > maxIPCount) {
                mostCommonIp = entry.getKey();
                maxIPCount = entry.getValue();
            }
        }


        // Find the most frequently occurring search term and its corresponding count
        String mostCommonSearchTerm = null;
        int maxSearchTermCount = 0;

        for (Map.Entry<String, Integer> entry : searchTermMap.entrySet()) {
            if (entry.getValue() > maxSearchTermCount) {
                mostCommonSearchTerm = entry.getKey();
                maxSearchTermCount = entry.getValue();
            }
        }


        // Set log data as properties on the request object
        request.setAttribute("logs", logs);
        request.setAttribute("mostCommonIP",mostCommonIp);
        request.setAttribute("maxIPCount",maxIPCount);
        request.setAttribute("mostCommonSearchTerm",mostCommonSearchTerm);
        request.setAttribute("maxSearchTermCount",maxSearchTermCount);
        request.setAttribute("averageTime",averageTime);

        RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
        dispatcher.forward(request, response);
    }
}
