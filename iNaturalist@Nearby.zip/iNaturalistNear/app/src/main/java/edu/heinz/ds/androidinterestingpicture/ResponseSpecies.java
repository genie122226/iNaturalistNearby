package edu.heinz.ds.androidinterestingpicture;

import java.util.List;

/*总体结构:

        total_results: 搜索标准匹配的总结果数。
        page: 当前页面索引。
        per_page: 每页显示的结果数量。
        results: 搜索标准匹配的具体结果数组。
        results 数组中的每个对象:

        count: 与此叶类群相关的观察计数。
        taxon: 描述叶类群的详细信息。
        taxon 对象:

        id: 类群的唯一标识符。
        iconic_taxon_id: 典型类群的标识符。
        iconic_taxon_name: 典型类群的名称。
        is_active: 表示类群是否活跃。
        name: 类群的科学名称。
        preferred_common_name: 类群的首选通用名称。
        rank: 类群在分类学中的等级。
        rank_level: 分类学等级的数值表示。
        ancestor_ids: 包含类群祖先的ID数组。
        colors: 与类群相关的颜色数组。
        conservation_status: 保护状况。
        conservation_statuses: 多个保护状况信息。
        default_photo: 类群的默认照片信息。
        establishment_means: 类群在某地的确立方式。
        observations_count: 类群的观察次数。
        preferred_establishment_means: 首选的确立方式。
        colors, conservation_status, conservation_statuses, default_photo, establishment_means 对象:

        这些对象包含关于类群特定方面的额外详细信息，例如颜色、保护状况、默认照片等。
        这个响应结构提供了一个详尽的视图，展示了哪些叶类群在观察中被发现，并包括与这些类群相关的各种详细信息。例如，它可以用来了解在特定条件下哪些特定物种被观察到，以及这些物种的科学分类、保护状况、常见颜色等。*/

public class ResponseSpecies {
    private int total_results;
    private int page;
    private int perPage;
    private List<Result> results;

    // getters and setters


    public int getTotal_results() {
        return total_results;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPerPage() {
        return perPage;
    }

    public void setPerPage(int perPage) {
        this.perPage = perPage;
    }

    public List<Result> getResults() {
        return results;
    }

    public void setResults(List<Result> results) {
        this.results = results;
    }

    public static class Result {
        private int count;
        private Taxon taxon;

        // getters and setters


        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public Taxon getTaxon() {
            return taxon;
        }

        public void setTaxon(Taxon taxon) {
            this.taxon = taxon;
        }

        public static class Taxon {
            private int id;
            private int iconicTaxonId;
            private String iconicTaxonName;
            private boolean isActive;
            private String name;
            private String preferredCommonName;
            private String rank;
            private int rankLevel;
            private List<Integer> ancestorIds;
            private List<Color> colors;
            private ConservationStatus conservationStatus;
            private List<ConservationStatus> conservationStatuses;
            private Photo default_photo;
            private EstablishmentMeans establishmentMeans;
            private int observations_count;
            private String preferredEstablishmentMeans;

            public String getWikipedia_url() {
                return wikipedia_url;
            }

            private String wikipedia_url;


            // getters and setters


            public int getId() {
                return id;
            }

            public int getIconicTaxonId() {
                return iconicTaxonId;
            }

            public String getIconicTaxonName() {
                return iconicTaxonName;
            }

            public boolean isActive() {
                return isActive;
            }

            public String getName() {
                return name;
            }

            public String getPreferredCommonName() {
                return preferredCommonName;
            }

            public String getRank() {
                return rank;
            }

            public int getRankLevel() {
                return rankLevel;
            }

            public List<Integer> getAncestorIds() {
                return ancestorIds;
            }

            public List<Color> getColors() {
                return colors;
            }

            public ConservationStatus getConservationStatus() {
                return conservationStatus;
            }

            public List<ConservationStatus> getConservationStatuses() {
                return conservationStatuses;
            }

            public Photo getDefaultPhoto() {
                return default_photo;
            }

            public EstablishmentMeans getEstablishmentMeans() {
                return establishmentMeans;
            }

            public int getObservationsCount() {
                return observations_count;
            }

            public String getPreferredEstablishmentMeans() {
                return preferredEstablishmentMeans;
            }

            public static class Color {
                private int id;
                private String value;

                // getters and setters

                public int getId() {
                    return id;
                }

                public String getValue() {
                    return value;
                }
            }

            public static class ConservationStatus {
                private int placeId;
                private Place place;
                private String status;

                public int getPlaceId() {
                    return placeId;
                }

                public Place getPlace() {
                    return place;
                }

                public String getStatus() {
                    return status;
                }

                // getters and setters
            }

            public static class Photo {
                private int id;
                private String attribution;
                private String licenseCode;
                private String url;
                private String medium_url;
                private String squareUrl;

                // getters and setters

                public int getId() {
                    return id;
                }

                public String getAttribution() {
                    return attribution;
                }

                public String getLicenseCode() {
                    return licenseCode;
                }

                public String getUrl() {
                    return url;
                }

                public String getMediumUrl() {
                    return medium_url;
                }

                public String getSquareUrl() {
                    return squareUrl;
                }
            }

            public static class EstablishmentMeans {
                private String establishmentMeans;
                private Place place;

                // getters and setters

                public String getEstablishmentMeans() {
                    return establishmentMeans;
                }

                public Place getPlace() {
                    return place;
                }
            }
        }
    }

    public static class Place {
        private int id;
        private String name;
        private String displayName;

        // getters and setters

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getDisplayName() {
            return displayName;
        }
    }
}
