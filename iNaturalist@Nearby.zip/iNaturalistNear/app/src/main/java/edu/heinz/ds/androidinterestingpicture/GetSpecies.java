package edu.heinz.ds.androidinterestingpicture;

import android.app.Activity;
//import android.os.Build;
//import android.support.annotation.RequiresApi;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.URL;
import java.util.Enumeration;

import java.net.HttpURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.google.gson.Gson; // 确保您的项目包含了Gson库
import android.net.Uri; // 对于 Uri.encode() 方法

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;


/*
 * This class provides capabilities to search for the observation of nearby species.  The method "search" is the entry to the class.
 * Network operations cannot be done from the UI thread, therefore this class makes use of inner class BackgroundTask that will do the network
 * operations in a separate worker thread.  However, any UI updates should be done in the UI thread so avoid any synchronization problems.
 * onPostExecution runs in the UI thread, and it calls the ImageView pictureReady method to do the update.
 *
 */
public class GetSpecies {
    InterestingPicture ip = null;   // for callback
    String searchTerm = null;       // search Flickr for this word
    String selectedMonth;
    String selectedYear;
    String selectedArea;
    ResponseSpecies responseSpecies;
    String IP;

    int resultNumber;

    public void search(String IP, String searchTerm, String selectedMonth, String selectedYear, String selectedArea, Activity activity, InterestingPicture ip) {
        this.ip = ip;
        this.searchTerm = searchTerm;
        this.selectedArea = selectedArea;
        this.selectedYear = selectedYear;
        this.selectedMonth = selectedMonth;
        this.IP = IP;
        new BackgroundTask(activity).execute();
    }


    private class BackgroundTask {

        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        private void startBackground() {
            new Thread(new Runnable() {
                public void run() {

                    try {
                        doInBackground();
                    } catch (MalformedURLException e) {
                        throw new RuntimeException(e);
                    }
                    // This is magic: activity should be set to MainActivity.this
                    //    then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        private void execute() {
            // There could be more setup here, which is why
            //    startBackground is not called directly
            startBackground();
        }

        private void doInBackground() throws MalformedURLException {
            responseSpecies = search(IP, searchTerm, selectedMonth, selectedYear, selectedArea);
            resultNumber = responseSpecies.getTotal_results();
            System.out.println("here result Number = " + resultNumber);
        }

        public void onPostExecute() {
            ip.apiJsonReady(resultNumber, searchTerm, responseSpecies);
        }

        private ResponseSpecies search(String IP, String searchTerm, String selectedMonth, String selectedYear, String selectedArea) {

            String urlstring = "https://congenial-space-telegram-wr7x4qg5vrwp29wv5-8080.app.github.dev/inaturalist";

            System.out.println("here put out the urlstring to request");

            try {
                URL url = new URL(urlstring);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("POST");
                con.setRequestProperty("Content-Type", "application/json; utf-8");
                con.setDoOutput(true);

                System.out.println("here check1");

                Gson gson = new Gson();
                SearchRequest sr = new SearchRequest();
                sr.setIP(IP);
                sr.setSearchTerm(searchTerm);
                sr.setSelectedArea(selectedArea);
                sr.setSelectedMonth(selectedMonth);
                sr.setSelectedYear(selectedYear);

                String searchRequest = gson.toJson(sr);


                System.out.println("here check2");


                try (OutputStream os = con.getOutputStream()) {

                    System.out.println("here check3");

                    byte[] input = searchRequest.getBytes("utf-8");
                    os.write(input, 0, input.length);
                    System.out.println("here has putout");
                }

                // Dealing with response
                int responseCode = con.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    try (BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line.trim());
                        }
                        responseSpecies = gson.fromJson(response.toString(), ResponseSpecies.class);
                        return responseSpecies;
                    }
                }
            } catch (ProtocolException e) {
                throw new RuntimeException(e);
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            } catch (UnsupportedEncodingException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            return null;

        }
    }
}





