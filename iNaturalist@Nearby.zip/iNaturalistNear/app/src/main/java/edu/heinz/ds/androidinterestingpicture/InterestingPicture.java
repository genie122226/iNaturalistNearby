package edu.heinz.ds.androidinterestingpicture;

import android.view.View;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.text.util.Linkify;
import android.content.Intent;
import android.net.Uri;
import java.lang.CharSequence;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;


import androidx.appcompat.app.AppCompatActivity;

public class InterestingPicture extends AppCompatActivity {

    InterestingPicture me = this;

    private String selectedYear = null;
    private String selectedMonth = null;
    private String selectedArea;

    private String simulatedIPAddress = null;

    String ipAddress;

    private int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        System.out.println("here 0");

        setupMainLayout();
    }

    private void setupMainLayout() {

        /*
         * The click listener will need a reference to this object, so that upon successfully finding a picture from Flickr, it
         * can callback to this object with the resulting picture Bitmap.  The "this" of the OnClick will be the OnClickListener, not
         * this InterestingPicture.
         */
        final InterestingPicture ma = this;

        Spinner spinner_time = findViewById(R.id.count_time);
        ArrayAdapter<CharSequence> adapter_time = ArrayAdapter.createFromResource(this,
                R.array.count_time_spinner_options, R.layout.custom_spinner_item);
        adapter_time.setDropDownViewResource(R.layout.custom_spinner_dropdown_item);
        spinner_time.setAdapter(adapter_time);

        Spinner spinner_area = findViewById(R.id.count_area);
        ArrayAdapter<CharSequence> adapter_area = ArrayAdapter.createFromResource(this,
                R.array.count_area_spinner_options, R.layout.custom_spinner_item);
        adapter_area.setDropDownViewResource(R.layout.custom_spinner_dropdown_item);
        spinner_area.setAdapter(adapter_area);

        // 初始化 Spinner 控件
        SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
        String currentYear = yearFormat.format(new Date());
        SimpleDateFormat monthFormat = new SimpleDateFormat("MM");
        String currentMonth = monthFormat.format(new Date());

        // System.out.println("here is the set up of Spinner?");

        spinner_time.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedTime = parent.getItemAtPosition(position).toString(); // 获取选择的时间
                switch (selectedTime){
                    case "1 month":
                        if(currentMonth == "01"){
                            selectedYear = Integer.toString(Integer.parseInt(currentYear)-1);
                            selectedMonth = "12";
                        }
                        else{
                            selectedYear = currentYear;
                            selectedMonth = currentMonth;
                        }
                        break;
                    case "1 year":
                        selectedYear = currentYear;
                        selectedMonth = null;
                        System.out.println("here selectedYear="+selectedYear);
                        System.out.println("here selectedMonth="+selectedMonth);
                        break;
                    default:
                        selectedYear = currentYear;
                        selectedMonth = null;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        spinner_area.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String areaChoice = parent.getItemAtPosition(position).toString();
                switch (areaChoice){
                    case "1 km":
                        selectedArea = "1";
                        break;
                    case "2 km":
                        selectedArea = "2";
                        break;
                    case "5 km":
                        selectedArea = "5";
                        break;
                    case "10 km":
                        selectedArea = "10";
                        break;
                    default:
                        selectedArea = "5";
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = (Button)findViewById(R.id.submit);


        // Add a listener to the send button
        submitButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                String searchTerm = ((EditText)findViewById(R.id.searchTerm)).getText().toString();
                simulatedIPAddress = ((EditText)findViewById(R.id.simulatedIP)).getText().toString();
                ipAddress = getSimulatedIPAddress();
                if(ipAddress == null) ipAddress = "71.182.171.44";
                System.out.println("hereIP="+ipAddress);
                System.out.println("searchTerm = " + searchTerm);
                System.out.println("Selected Year = " + selectedYear);
                System.out.println("Selected Month = " + selectedMonth);
                System.out.println("Selected area = " + selectedArea);
                GetSpecies gs = new GetSpecies();
                setContentView(R.layout.activity_main2);
                setupSecondaryLayout();
                System.out.println("here1");
                gs.search(ipAddress, searchTerm, selectedMonth, selectedYear, selectedArea, me, ma); // Done asynchronously in another thread.  It calls ip.apiJsonReady() in this thread when complete.
            }
        });
    }

    private void setupSecondaryLayout() {
        Button home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setContentView(R.layout.activity_main);
                setupMainLayout();
            }
        });
    }

    /*
     * This is called by the GetPicture object when the picture is ready.  This allows for passing back the Bitmap picture for updating the ImageView
     */
    public void apiJsonReady(int resultNumber, String searchTerm, ResponseSpecies responseSpecies) {

        System.out.println("here2");

        final InterestingPicture ma = this;

        TextView feedbackTextView = (TextView) findViewById(R.id.feedbackTextView);

        feedbackTextView.setText("There are "+resultNumber+" for ["+searchTerm+"]");

        if(resultNumber != 0){
            GetOneOfResult gor = new GetOneOfResult();
            System.out.println("here2.5");
            gor.search(responseSpecies, resultNumber,0, me, ma);
        }
        else{
            TextView nameView = (TextView)findViewById(R.id.NameTextView) ;
            TextView commonNameView = (TextView)findViewById(R.id.CommonNameTextView) ;
            TextView countView = (TextView)findViewById(R.id.CountTextView) ;
            TextView idView = (TextView)findViewById(R.id.idTextView) ;
            TextView activeView = (TextView)findViewById(R.id.activeTextView) ;
            TextView totalCountView = (TextView)findViewById(R.id.TotalCountTextView) ;
            TextView wikiView = (TextView)findViewById(R.id.WIKITextView) ;
            nameView.setVisibility(View.INVISIBLE);
            commonNameView.setVisibility(View.INVISIBLE);
            countView.setVisibility(View.INVISIBLE);
            idView.setVisibility(View.INVISIBLE);
            activeView.setVisibility(View.INVISIBLE);
            totalCountView.setVisibility(View.INVISIBLE);
            wikiView.setVisibility(View.INVISIBLE);
            TextView resultCountTextView = (TextView)findViewById(R.id.ResultCountTextView);
            resultCountTextView.setText("Return Home for More Search");
        }
    }

    public void resultReady(ResponseSpecies responseSpecies, int resultNumber, int index, Bitmap picture, String[] data) {

        final InterestingPicture ma = this;
        this.index = index;

        System.out.println("here4");


        TextView nameView = (TextView)findViewById(R.id.NameTextView) ;
        TextView commonNameView = (TextView)findViewById(R.id.CommonNameTextView) ;
        TextView countView = (TextView)findViewById(R.id.CountTextView) ;
        ImageView taxonPictureView = (ImageView)findViewById(R.id.TaxonPicture);
        TextView idView = (TextView)findViewById(R.id.idTextView) ;
        TextView activeView = (TextView)findViewById(R.id.activeTextView) ;
        TextView totalCountView = (TextView)findViewById(R.id.TotalCountTextView) ;
        TextView wikiView = (TextView)findViewById(R.id.WIKITextView) ;

        TextView resultCountTextView = (TextView)findViewById(R.id.ResultCountTextView);



        ImageView prev = findViewById(R.id.prev);
        prev.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if(index == 0)
                    return;
                GetOneOfResult gor = new GetOneOfResult();
                gor.search(responseSpecies, resultNumber, index-1, me, ma);
            }
        });

        ImageView next = findViewById(R.id.next);
        next.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                if(index == resultNumber-1)
                    return;
                GetOneOfResult gor = new GetOneOfResult();
                gor.search(responseSpecies, resultNumber, index+1, me, ma);
            }
        });



        if (picture != null && data!=null) {
            taxonPictureView.setImageBitmap(picture);
            System.out.println("picture");
            nameView.setText(data[0]);
            commonNameView.setText(data[1]);
            if (commonNameView.getText().toString().trim().isEmpty()) {
                commonNameView.setVisibility(View.GONE);
            } else {
                commonNameView.setVisibility(View.VISIBLE);
            }
            countView.setText("Count: "+data[2]);
            idView.setText(data[3]);
            activeView.setText(data[4]);
            totalCountView.setText(data[5]);
            wikiView.setText(data[6]);

            resultCountTextView.setText("Result "+(index+1));

            Linkify.addLinks(wikiView, Linkify.WEB_URLS);
            wikiView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String url = wikiView.getText().toString();
                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                }
            });

            taxonPictureView.setVisibility(View.VISIBLE);
        } else {
            taxonPictureView.setImageResource(R.mipmap.ic_launcher);
            System.out.println("No picture");
            taxonPictureView.setVisibility(View.INVISIBLE);
        }
    }

    public String getSimulatedIPAddress() {
        if (simulatedIPAddress != null) {
            return simulatedIPAddress;
        }
        return getIPAddress(); // used for actual android APP to get IP
    }

    // This is used for actual android APP to get IP.
    // But in this Project, since the virtual one has fixed IP, a fake ID inputted by user will replace the actual IP.
    public String getIPAddress() {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
                for (InetAddress addr : addrs) {
                    if (!addr.isLoopbackAddress() && addr instanceof Inet4Address) {
                        String ip = addr.getHostAddress();
                        return ip;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
