package edu.heinz.ds.androidinterestingpicture;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import com.google.gson.Gson;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import java.util.List;

/*
 * This class provides capabilities to view the result.  The method "search" is the entry to the class.
 * Network operations cannot be done from the UI thread, therefore this class makes use of inner class BackgroundTask that will do the network
 * operations in a separate worker thread.  However, any UI updates should be done in the UI thread so avoid any synchronization problems.
 * onPostExecution runs in the UI thread, and it calls the ImageView resultReady method to do the update.
 *
 */
public class GetOneOfResult {
    InterestingPicture ip = null;
    Bitmap picture = null;
    int index;
    int resultNumber;
    ResponseSpecies responseSpecies;
    String[] data;


    public void search(ResponseSpecies responseSpecies,int resultNumber, int index, Activity activity, InterestingPicture ip) {
        this.ip = ip;
        this.responseSpecies = responseSpecies;
        this.index = index;
        this.resultNumber = resultNumber;
        System.out.println("here3");
        new BackgroundTask(activity).execute();
    }


    private class BackgroundTask {

        private Activity activity; // The UI thread

        public BackgroundTask(Activity activity) {
            this.activity = activity;
        }

        private void startBackground() {

            System.out.println("here4");

            new Thread(new Runnable() {
                public void run() {

                    try {
                        doInBackground();
                    } catch (MalformedURLException e) {
                        throw new RuntimeException(e);
                    }
                    activity.runOnUiThread(new Runnable() {
                        public void run() {
                            onPostExecute();
                        }
                    });
                }
            }).start();
        }

        private void execute(){
            startBackground();
        }

        private void doInBackground() throws MalformedURLException {

            List<ResponseSpecies.Result> results = responseSpecies.getResults();
            ResponseSpecies.Result result = results.get(index);

            data = new String[7];
            data[0] = result.getTaxon().getName(); //Name
            data[1] = result.getTaxon().getPreferredCommonName(); //commonName
            data[2] = Integer.toString(result.getCount()); //count
            data[3] = Integer.toString(result.getTaxon().getId()); //ID
            data[4] = Boolean.toString(result.getTaxon().isActive()); //active
            data[5] = Integer.toString(result.getTaxon().getObservationsCount()); // total observation
            data[6] = result.getTaxon().getWikipedia_url();

            ResponseSpecies.Result.Taxon taxon = result.getTaxon();
            if (taxon != null) {
                //Default Photo
                ResponseSpecies.Result.Taxon.Photo photo = taxon.getDefaultPhoto();
                if(photo == null)System.out.println("here is no photo?");
                System.out.println("here6");
                if (photo != null) {
                    String urlString = photo.getMediumUrl();
                    URL url = new URL(urlString);
                    System.out.println("here7");
                    picture = getRemoteImage(url);
                    if(picture == null)System.out.println("here is no picture?");
                    else System.out.println("here picture:"+url);
                }
            }



        }

        public void onPostExecute() {

            ip.resultReady(responseSpecies, resultNumber, index, picture, data);
        }


        /*
         * Given a URL referring to an image, return a bitmap of that image
         */
        // @RequiresApi(api = Build.VERSION_CODES.P)
        private Bitmap getRemoteImage(final URL url) {

            try {
                final URLConnection conn = url.openConnection();
                conn.connect();
                BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
                Bitmap bm = BitmapFactory.decodeStream(bis);
                return bm;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
    }
}

