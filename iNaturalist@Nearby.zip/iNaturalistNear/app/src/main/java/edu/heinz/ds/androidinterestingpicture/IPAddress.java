package edu.heinz.ds.androidinterestingpicture;

//name: Anran Lin
//andrewID: anranlin

public class IPAddress {
    private String ip;
    private String latitude;
    private String longitude;

    public String getIp() {
        return ip;
    }

    public String getLatitude() {
        return latitude;
    }

    public String getLongitude() {
        return longitude;
    }
}
